<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        .error{
            color: #92a8d1;
        }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>register</title>

    <!-- Bootstrap -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

    <!-- External css -->
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <form id="register" action="save.php" method="POST">
        <div class="sidenav">
            <div class="login-main-text">
                <h2>Application<br> Register Page</h2>
                <p>Register from here to access.</p>
            </div>
        </div>
        <div class="main">
            <div class="col-md-6 col-sm-12">
                <div class="login-form">
                <form>
                    <div class="form-group">
                        <label>Name</label>
                        <input id="name" type="text" class="form-control" placeholder="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Surname</label>
                        <input id="surname" type="text" class="form-control" placeholder="surname" name="surname" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input id="email" type="text" class="form-control" placeholder="Email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input id="phone" type="text" class="form-control" placeholder="phone" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input id="password" type="password" class="form-control" placeholder="Password" name="password" required>
                    </div>
                    <button id="submit" type="submit" class="btn btn-black" name="register">Register</button>
                </form>
                </div>
            </div>
        </div>
    </form>

    <!-- External JS -->
    <script src="main.js"></script>
</body>
</html>










