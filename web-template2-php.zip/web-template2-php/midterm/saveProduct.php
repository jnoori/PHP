<?php
    //this file called from register.php
    //database connection
    $host = 'localhost';
    $user = 'root';
    $password = 'root'; //for mamp user and password is root
    $db = 'midterm';
    $dsn;
    //data source name
    $dsn = 'mysql:host=' .$host. ';dbname=' .$db;
    //create a PDO instance
    try {
        $conn = new PDO($dsn, $user, $password,
            array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        echo "connected successfully!<br />";
        //set the fetch default method for the following connection
        $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
        //insert data into db or not
        try {
            //create a statement from table
            $sql = "INSERT INTO 
            products (`name`, price, category)
            VALUES
            (:thename, :price, :category)
        ";
        //pass data to preparestatement
        $prepareStatement = $conn->prepare($sql);
        $prepareStatement->execute([
            'thename' => $_POST['name'],
            'price' => $_POST['price'],
            'category' => $_POST['category']
        ]);
        echo "<br />insert product successfully";
        echo "<meta http-equiv=\"refresh\" content=\"4; URL='dashboard.php?message=1'\" />"; //content -> wait 4 second
        } catch (Exception $e) {
            echo "Error: " .$e->getMessage(). "<br>";
            echo "<meta http-equiv=\"refresh\" content=\"4; URL='newProduct.php?message=2'\" />";
        }
    } catch (PDOException $ex) {
        die("cannot conncet to database " .$ex->getMessage());
    } 
?>