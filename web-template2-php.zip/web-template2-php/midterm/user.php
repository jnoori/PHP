<?php
    class user{
        // fields or properties
        private $name;
        private $surname;
        private $email;
        private $phone;
        private $password;

        //getters and setters
        public function __get($property){ //magic method
            if(property_exists($this, $property)){
                return $this->$property;
            }
            return "doesn't exist";
        }


        public function __set($property, $value) {
            if(property_exists($this, $property)){
                $this->$property = $value;
            }else{
                echo "<P>property set error</p>";
            }
        }

        public function listUsers(){
            //database connection
            $host = 'localhost';
            $user = 'root';
            $password = 'root'; //for mamp user and password is root
            $db = 'midterm';
            $dsn;
            //data source name
            $dsn = 'mysql:host=' .$host. ';dbname=' .$db;
            //create a PDO instance
            try {
                $conn = new PDO($dsn, $user, $password,
                    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
                //set the fetch default method for the following connection
                $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
                echo "connected successfully!";
                echo "<hr>";
                //select data from db 
                $sql = "SELECT * FROM users 
                WHERE active = 1;
                ";
                $prepareStatement = $conn->prepare($sql);
                $prepareStatement = $conn->prepare($sql);
                $prepareStatement->execute();
                
                while($row = $prepareStatement->fetch()){
                    $this->name = $row->name;
                    $this->surname = $row->surname;
                    $this->email = $row->email;
                    $this->phone = $row->phone;
                    echo 'name: '. $this->name .'<br />'.
                    'surname: '. $this->surname.'<br />'.
                    'email: '. $this->email.'<br />'.
                    'phone: '. $this->phone.'<br />' .'<hr>';
                }
            } catch (PDOException $ex) {
                die("cannot conncet to database " .$ex->getMessage());
            } 
             
        }
    }
?>