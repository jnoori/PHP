<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        .error{
            color: #92a8d1;
        }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>register</title>

    <!-- Bootstrap -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

    <!-- External css -->
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <!-- form -->
        <form id="newProduct" action="saveProduct.php" method="POST">
        <div class="sidenav">
            <div class="login-main-text">
                <h2>Application<br> New Product Page</h2>
                <p>Enter new product information.</p>
            </div>
        </div>
        <div class="main">
            <div class="col-md-6 col-sm-12">
                <div class="login-form">
                <form>
                    <div class="form-group">
                        <label>Name</label>
                        <input id="name" type="text" class="form-control" placeholder="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Price</label>
                        <input id="price" type="text" class="form-control" placeholder="price" name="price" required>
                    </div>
                    <div class="form-group">
                        <label>Category</label>
                        <input id="category" type="text" class="form-control" placeholder="category" name="category" required>
                    </div>
                    <button id="submit" type="submit" class="btn btn-black" name="submit">Add</button>
                </form>
                </div>
            </div>
        </div>
    </form>
    </div>

    <!-- External JS -->
    <script src="main.js"></script>
</body>
</html>










