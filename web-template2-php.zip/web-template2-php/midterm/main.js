$(document).ready(function() {
  $("#submit").click(function() {
    var is_error = false;
    if ($("#name").val() === "") {
      $(this).addClass("has-error");
      is_error = true;
    }
    if ($("#email").val() === "") {
      $(this).addClass("has-error");
      is_error = true;
    }
    if ($("#password").val() === "") {
      $(this).addClass("has-error");
      is_error = true;
    }

    if ($("#password").val().length < 8) {
      $(this).addClass("has-error");
      $("#password").attr("placeholder", "at least 8 character");
      is_error = true;
    }

    if (is_error) {
      alert("please fill the information appropriately");
    }
  });
});
