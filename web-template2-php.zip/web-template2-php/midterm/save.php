<?php
    //this file called from register.php
    //database connection
    $host = 'localhost';
    $user = 'root';
    $password = 'root'; //for mamp user and password is root
    $db = 'midterm';
    $dsn;
    //data source name
    $dsn = 'mysql:host=' .$host. ';dbname=' .$db;
    //create a PDO instance
    try {
        $conn = new PDO($dsn, $user, $password,
            array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
            echo "connected successfully!<br />";
            //set the fetch default method for the following connection
            $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    } catch (PDOException $ex) {
        die("cannot conncet to database " .$ex->getMessage());
    } 
    
    //insert data into db or not
    try {
        //create a statement from table
        $sql = "INSERT INTO 
        users (`name`, surname, email, phone, `password`)
        VALUES
        (:thename, :surname, :email, :phone, :pass)
    ";
    //pass data to preparestatement
    $prepareStatement = $conn->prepare($sql);
    $prepareStatement->execute([
        'thename' => $_POST['name'],
        'surname' => $_POST['surname'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone'],
        'pass' => md5($_POST['password'])
    ]);
    echo "<br />insert successfully";
    echo "<meta http-equiv=\"refresh\" content=\"4; URL='login.php?message=1'\" />"; //content -> wait 4 second
    } catch (Exception $e) {
        echo "Error: " .$e->getMessage(). "<br>";
        echo "<meta http-equiv=\"refresh\" content=\"4; URL='register.php?message=2'\" />";
    }
?>