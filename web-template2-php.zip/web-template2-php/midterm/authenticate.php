<?php
    //this file called from register.php
    //database connection
    $host = 'localhost';
    $user = 'root';
    $password = 'root'; //for mamp user and password is root
    $db = 'midterm';
    $dsn;
    //data source name
    $dsn = 'mysql:host=' .$host. ';dbname=' .$db;
    //create a PDO instance
    try {
        $conn = new PDO($dsn, $user, $password,
            array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
            //set the fetch default method for the following connection
            $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
            echo "connected successfully!";
    } catch (PDOException $ex) {
        die("cannot conncet to database " .$ex->getMessage());
    } 
    
    //select data from db
    if(isset($_POST['login'])){  
        //Retrieve the field values from our login form.
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        
        //Retrieve the user account information for the given email.
        $sql = "SELECT email,  `password` FROM users 
            WHERE email = :email AND `password` = :pass";
        $prepareStatement = $conn->prepare($sql);
        $prepareStatement->bindParam(':email', $email);
        $prepareStatement->bindParam(':pass', $password);
        $prepareStatement->execute();
        $result = $prepareStatement->fetchAll(\PDO::FETCH_ASSOC);
        if(count($result) == 1){
            echo "<meta http-equiv=\"refresh\" content=\"0; URL='dashboard.php?message=1'\" />";
        }else{
            echo "<meta http-equiv=\"refresh\" content=\"4; URL='login.php?message=1'\" />";
        } 
    }else{
        echo "<meta http-equiv=\"refresh\" content=\"4; URL='login.php?message=1'\" />";
    }

?>