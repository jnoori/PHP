<?php

class Account{
    
    private $name;
    private $lastName;
    private $birthDay;
    private $accountNumberChecking;
    private $accountNumberSaving;
    private $checking;
    private $saving;

    //getters
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        } else {
            return "";
        }
    }

    //setters
    public function __set($property, $value){
        if(property_exists($this,$property)){
            if($this->$property != $this->birthYear){
                $this->$property = $value;
            }
        } else{
            echo "<p> property set error</p>";
        }
    }

    public function __construct($args =[]){

        $this->name = isset($args['name']) ? $args['name'] : "";
        $this->lastName = isset($args['lastName']) ? $args['lastName'] : "";
        $this->birthDay = isset($args['birthDay']) ? $args['birthDay'] : "";
        $this->accountNumberChecking = isset($args['accountNumberChecking']) ? $args['accountNumberChecking'] : "";
        $this->accountNumberSaving = isset($args['accountNumberSaving']) ? $args['accountNumberSaving'] : "";
        $this->checking = isset($args['checking']) ? $args['checking'] : "";
        $this->saving = isset($args['saving']) ? $args['saving'] : "";

    }

    public function summary(){
        echo $this->name ;
        echo $this->lastName;
        echo $this->birthDay;
        echo $this->accountNumberChecking;
        echo $this->accountNumberSaving;
        echo $this->checking;
        echo $this->saving;
    }

    public function withdrawl($amount, $accountNumber){

        if($amount <= 0){
            echo "<div style='color:red'> you can not withdraw $amount</div>";
            return ""; 
        } 
        if($accountNumber == $this->accountNumberChecking){
            if($amount <= $this->checking){
                $this->checking -= $amount;
            } else {
                echo "<div style='color:red'> You have $this->checking CAD in your account you can not withdrawl $amount</div>";
            }
        }else if($accountNumber == $this->accountNumberSaving){
            if($amount <= $this->saving){
                $this->saving -= $amount;
            } else {
                echo "<div style='color:red'> You have $this->saving CAD in your account you can not withdrawl $amount</div>";
            }
        }
    }

    public function deposit($amount, $accountNumber){

        if($amount <= 0){
            echo "<div> you can not deposit $amount CAD</div>";
            return ""; 
        } 
        if($accountNumber == $this->accountNumberChecking){
            if($amount <= $this->checking){
                $this->checking += $amount;
            } else {
                echo "<div style='color:red'> You have $this->checking CAD in your account you can not withdrawl $amount</div>";
            }
        }else if($accountNumber == $this->accountNumberSaving){
            if($amount <= $this->saving){
                $this->saving += $amount;
            } else {
                echo "<div style='color:red'> You have $this->saving CAD in your account you can not withdrawl $amount</div>";
            }
        }
    }

}