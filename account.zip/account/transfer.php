<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
</head>
<body>
<form class="ui form container">
  <h2> John Doe</h2>
  <div class="field">
    <label>amount</label>
    <input type="number"/>
  </div>
  <button type="submit" class="ui button">Withdrawl</button>
  <button type="submit" class="ui button">Deposit</button>
</form>

<hr class="ui container">

<div class="ui container">
  <table class="ui celled table ">
    <thead class="">
      <tr class="">
        <th class="">Account</th>
        <th class="">Account number</th>
        <th class="">Balance</th>
      </tr>
    </thead>
    <tbody class="">
      <tr class="">
        <td class="">Checking</td>
        <td class="">10003</td>
        <td class="">120</td>
      </tr>
      <tr class="warning">
        <td class="">Saving</td>
        <td class=""> N/A</td>
        <td class=""> N/A</ßtd>
      </tr>

    </tbody>
  </table>
</div>
    
</body>
</html>