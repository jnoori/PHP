<?php
    require_once 'Account.php';
    session_start();
    //save data in global array
    if(isset($_POST['submit'])){
        $_SESSION['account']= new Account([
            'name' => $_POST['name'],
            'lastName' => $_POST['lastName'],
            'birthDay' => $_POST['birthDay'],
            'accountNumberChecking' => $_POST['accountNumberChecking'],
            'accountNumberSaving' => $_POST['accountNumberSaving'],
            'checking' => $_POST['checking'],
            'saving' => $_POST['saving'],
        ]);  
    }
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Account</title>
  </head>
  <body>
    <div class="container">
    <h1>Account</h1>
        <form action= "showInfo.php" method="POST">
            <div class="form-group">
                <label for="amount">amount</label>
                <input type="text" class="form-control" id="amount" aria-describedby="emailHelp" name="amount">
                <label for="account">account</label>
                <select id="account" class="form-control" id="exampleFormControlSelect1" name="account">
                    <option>checking</option>
                    <option>saving</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" name="deposit">deposit</button>
            <button type="submit" class="btn btn-primary" name="withdrawal">withdrawal</button>
            <button type="submit" class="btn btn-primary" name="clearSession">clearSession</button>
        </form>

        <h2> information: </h2>
        <p id="showInfo"><?php 
                $account="";
                if(isset($_POST['deposit'])){
                    //getting account number
                    if($_POST['account'] == "checking"){
                        $account = $_SESSION['account']->accountNumberChecking;
                    }else{
                        $account = $_SESSION['account']->accountNumberSaving;
                    }
                    $_SESSION['account']->deposit($_POST['amount'], $account);
                }else if(isset($_POST['withdrawal'])){
                    if($_POST['account'] == "checking"){
                        $account = $_SESSION['account']->accountNumberChecking;
                    }else{
                        $account = $_SESSION['account']->accountNumberSaving;
                    }
                    $_SESSION['account']->withdrawl((int)$_POST['amount'], $account);
                }else if(isset($_POST['clearSession'])){
                    session_destroy();
                }
            echo "<h2>full name: " .$_SESSION['account']->name. " " .$_SESSION['account']->lastName. "</h2>";
            ?>
        </p>

        <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">Account</th>
                <th scope="col">Account Number</th>
                <th scope="col">Balance</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>checking</td>
                    <td><?php echo $_SESSION['account']->accountNumberChecking ?></td>
                    <td><?php echo $_SESSION['account']->checking ?></td>
                </tr>
                <tr>
                    <td>Saving</td>
                    <td><?php echo $_SESSION['account']->accountNumberSaving ?></td>
                    <td><?php echo $_SESSION['account']->saving ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    

    <!-- Optional JavaScript -->
    <!-- External JS -->
    <script src="main.js"></script>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>