<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
</head>
<body>

<div class="ui container">
    <h1>Please provide customer information</h1>
</div>

<form class="ui form container" action="transfer.php">
  <div class="field">
    <label>Name</label>
    <input placeholder="Name" />
  </div>
  <div class="field">
    <label>Last Name</label>
    <input placeholder="Last Name" />
  </div>
  <div class="field">
    <label>Birthday</label>
    <input placeholder="Birthday" />
  </div>
  <div class="field">
    <label>Account Number</label>
    <input placeholder="Account Number" />
  </div>
  <div class="field">
    <label>Initial balance</label>
    <input placeholder="Initial balance" />
  </div>
  <button type="submit" class="ui button">Submit</button>
</form>
    
</body>
</html>