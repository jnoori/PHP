<?php
    require_once 'Account.php';

    $account1 = new Account([
        'name' => 'javad',
        'lastName' => 'noori',
        'acountNumber' => '123456789',
        'birthDay' => '1985',
        'checking' => 200
    ]);
    
?>