<?php
//database connection
$host = 'localhost';
$user = 'root';
$password = 'root'; //for mamp user and password is root
$db = 'javad';
$dsn;
//data source name
$dsn = 'mysql:host=' . $host . ';dbname=' . $db;
try {
    $conn = new PDO(
        $dsn,
        $user,
        $password,
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
    );
    //set the fetch default method for the following connection
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
} catch (PDOException $ex) {
    die("cannot conncet to database " . $ex->getMessage());
}
