<?php
    $menus = array("home"=>"index.php",
                     "about"=>"about.php", 
                     "AddUsers"=>"addUsers.php",
                     "listUsers"=>"listUsers.php",
                     "contact"=>"contact.php"
                    );
?>