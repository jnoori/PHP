<?php 
    require_once 'header.php';
    require_once 'functions.php';
    echo "<h1> Users </h1>";
    $userArray = listUsers();
    foreach ($userArray as $user) {
        echo 'name: ' .$user->name. '<br>'.
        'surname: ' .$user->surname. '<br>'.
        'email: ' .$user->email. '<br>';
    }
    require_once 'footer.php';
?>