$(document).ready(function() {
  // Add smooth scrolling to all links
  $("#top").on("click", function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $("html, body").animate(
        {
          scrollTop: $(hash).offset().top
        },
        8000,
        function() {
          // Add hash (#) to URL when done scrolling (default click behavior)
          window.location.hash = hash;
        }
      );
    } // End if
  });

  $("#submit").click(function() {
    var is_error = false;
    if ($("#name").val() === "") {
      $(this).addClass("has-error");
      is_error = true;
    }
    if ($("#email").val() === "") {
      $(this).addClass("has-error");
      is_error = true;
    }
    if ($("#password").val() === "") {
      $(this).addClass("has-error");
      is_error = true;
    }

    if ($("#password").val().length < 8) {
      $(this).addClass("has-error");
      $("#password").attr("placeholder", "at least 8 character");
      is_error = true;
    }

    if (is_error) {
      alert("please fill the information appropriately");
    }
  });
});
