<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!------ Include the above in your HEAD tag ---------->

        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <!-- External CSS -->
        <link rel="stylesheet" type="text/css" href="css/style2.css">
        <!-- favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon.png">
        <link rel="icon" type="image/jpg" sizes="32x32" href="favicon/favicon-32x32.png">
        <link rel="icon" type="image/jpg" sizes="16x16" href="favicon/favicon-16x16.png">
        <link rel="manifest" href="favicon/site.webmanifest">
        <title>contact</title>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-5 mx-auto">
                    <div id="first">
                        <div class="myform form ">
                            <div class="logo mb-3">
                                <div class="col-md-12 text-center">
                                    <h1>contact</h1>
                                </div>
                            </div>
                            <form action="save.php" method="post" name="login">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">sender</label>
                                    <input type="text" name="sender" class="form-control" id="sender" placeholder="sender">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">to</label>
                                    <input type="text" name="to_whom" class="form-control" id="to_whom" placeholder="to">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">subject</label>
                                    <input type="text" name="subject" class="form-control" id="subject" placeholder="subject">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">message</label>
                                    <textarea type="message" name="message" class="form-control" id="message" placeholder="message"></textarea>
                                </div>
                                <div class="col-md-12 text-center ">
                                    <button type="submit" class=" btn btn-block mybtn btn-primary tx-tfm" name="saveContact">Send</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- External JS -->
        <script src="js/main.js"></script>
    </body>
</html>