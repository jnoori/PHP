<?php
    class user{
        // fields or properties
        protected $id;
        protected $name;
        protected $surname;
        protected $email;
        protected $phone;
        protected $password;
        protected $created_at;

        //getters and setters
        public function __get($property){ //magic method
            if(property_exists($this, $property)){
                return $this->$property;
            }
            return "doesn't exist";
        }


        public function __set($property, $value) {
            if(property_exists($this, $property)){
                $this->$property = $value;
            }else{
                echo "<P>property set error</p>";
            }
        }

    }
?>