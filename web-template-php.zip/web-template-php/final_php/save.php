<?php
    require_once 'config/db.php';
    if(isset($_POST['register'])){
        //insert data into db or not
        try {
            //create a statement from table
            $sql = "INSERT INTO 
            users (`name`, surname, email, phone, `password`)
            VALUES
            (:thename, :surname, :email, :phone, :pass)
        ";
        //pass data to preparestatement
        $prepareStatement = $conn->prepare($sql);
        $prepareStatement->execute([
            'thename' => $_POST['name'],
            'surname' => $_POST['surname'],
            'email' => $_POST['email'],
            'phone' => $_POST['phone'],
            'pass' => md5($_POST['password'])
        ]);
        echo "<br />insert successfully";
        echo "<meta http-equiv=\"refresh\" content=\"4; URL='listUsers.php?message=1'\" />"; //content -> wait 4 second
        } catch (Exception $e) {
            echo "Error: " .$e->getMessage(). "<br>";
            echo "<meta http-equiv=\"refresh\" content=\"4; URL='addUsers.php?message=2'\" />";
        }
    }else if(isset($_POST['saveContact'])){
        try {
            //create a statement from table
            $sql = "INSERT INTO 
            contacts (sender, to_whom, `subject`, `message`)
            VALUES
            (:sender, :to_whom, :thesubject, :themessage)
        ";
        //pass data to preparestatement
        $prepareStatement = $conn->prepare($sql);
        $prepareStatement->execute([
            'sender' => $_POST['sender'],
            'to_whom' => $_POST['to_whom'],
            'thesubject' => $_POST['subject'],
            'themessage' => $_POST['message']
        ]);
        echo "<br />insert to contact successfully";
        echo "<meta http-equiv=\"refresh\" content=\"4; URL='index.php?message=1'\" />"; //content -> wait 4 second
        } catch (Exception $e) {
            echo "Error: " .$e->getMessage(). "<br>";
            echo "<meta http-equiv=\"refresh\" content=\"4; URL='contact.php?message=2'\" />";
        }
    }


    // else if(isset($_POST['login'])){  
    //     //Retrieve the field values from our login form.
    //     $email = $_POST['email'];
    //     $password = md5($_POST['password']);
        
    //     //Retrieve the user account information for the given email.
    //     $sql = "SELECT email,  `password` FROM users 
    //         WHERE email = :email AND `password` = :pass";
    //     $prepareStatement = $conn->prepare($sql);
    //     $prepareStatement->bindParam(':email', $email);
    //     $prepareStatement->bindParam(':pass', $password);
    //     $prepareStatement->execute();
    //     $result = $prepareStatement->fetchAll(\PDO::FETCH_ASSOC);
    //     if(count($result) == 1){
    //         echo "<meta http-equiv=\"refresh\" content=\"0; URL='index.php?message=1'\" />";
    //     }else{
    //         echo "<meta http-equiv=\"refresh\" content=\"4; URL='login.php?message=1'\" />";
    //     } 
    // }
    
?>
