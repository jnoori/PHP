<?php
 function listUsers(){
    require 'config/db.php';
    require 'user.php';
    try {
        $sql = "SELECT * FROM users 
        WHERE active = 1;
        ";
        $prepareStatement = $conn->prepare($sql);
        $prepareStatement->execute();
        $userArray;
        $userRow;
        while($row = $prepareStatement->fetch()){
            $user = new user();
            $user->id = $row->id;
            $user->name = $row->name;
            $user->surname = $row->surname;
            $user->email = $row->email;
            $user->phone = $row->phone;
            $user->password = $row->password;
            $user->created_at = $row->created_at;

            // $userRow[0] = $row->id;
            // $userRow[1] = $row->name;
            // $userRow[2] = $row->surname;
            // $userRow[3] = $row->email;
            // $userRow[4] = $row->password;
            // $userRow[5] = $row->created_date;
            // $userArray[] = $userRow;

            $userArray[] = $user;
        }
        return $userArray;
    } catch (PDOException $ex) {
        die("cannot conncet to database " .$ex->getMessage());
    } 
}

function home(){
    require 'config/db.php';
    try {
        $sql = "SELECT title FROM pages 
        WHERE pages.title = 'home'
        AND active = 1;
        ";
        $prepareStatement = $conn->prepare($sql);
        $prepareStatement->execute();
        $title = $prepareStatement->fetchColumn();
        return $title;
    } catch (PDOException $ex) {
        die("cannot conncet to database " .$ex->getMessage());
    }
}
function about(){
    require 'config/db.php';
    try {
        $sql = "SELECT title FROM pages 
        WHERE pages.title = 'about'
        AND active = 1;
        ";
        $prepareStatement = $conn->prepare($sql);
        $prepareStatement->execute();
        $title = $prepareStatement->fetchColumn();
        return $title;
    } catch (PDOException $ex) {
        die("cannot conncet to database " .$ex->getMessage());
    }
}
?>