<?php 
   require_once 'config/db.php';
   require_once 'config/setting.php';
?>
<!doctype html>
<html lang="en">

<head>
   <!-- Required meta tags -->
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="msapplication-TileColor" content="#ffffff">
   <meta name="msapplication-TileImage" content="/ms-icon-144x144.jpg">
   <meta name="theme-color" content="#ffffff">
   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
   <!-- External CSS -->
   <link rel="stylesheet" type="text/css" href="css/style.css">
   <!-- favicon -->
   <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon.png">
   <link rel="icon" type="image/jpg" sizes="32x32" href="favicon/favicon-32x32.png">
   <link rel="icon" type="image/jpg" sizes="16x16" href="favicon/favicon-16x16.png">
   <link rel="manifest" href="favicon/site.webmanifest">
   <!-- google fonts -->
   <link href="https://fonts.googleapis.com/css?family=Fjalla+One&display=swap" rel="stylesheet">
   <title> Final Exam PHP </title>
</head>

<body class="bg">
   <!-- **************** Start of navbar **************** -->
   <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
      <a class="navbar-brand" href="#">
         <img class="img-fluid logo spin" src="image/logo.png" alt="logo">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
         <?php
            echo '<ul class="navbar-nav">';
            foreach ($menus as $key => $value){
               echo '<li class="nav-item">
                  <a class="nav-link" href="' 
                  .$value. 
                  '">'
                  .$key.
                  '<span class="sr-only">(current)</span></a></li>';
            }
            echo '</ul>';
         ?>
      </div>
   </nav>
   <!-- **************** End of navbar **************** -->
   <!-- **************** Start of scroll up **************** -->
   <div class="scrollUp">
      <a href="#top" title="scroll up"><i class="fas fa-arrow-alt-circle-up arrow"></i></a>
   </div>
   <!-- **************** End of scroll up  **************** -->
   <!-- **************** Start of content **************** -->
   <div class="container">