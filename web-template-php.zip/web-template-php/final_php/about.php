<?php 
    require_once 'header.php';
    require_once 'functions.php';
    $title = about();
    echo '<h1>' .$title. '</h1>';
    require_once 'footer.php';
?>