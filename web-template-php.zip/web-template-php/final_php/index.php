<?php 
    require_once 'header.php';
    require_once 'functions.php';
    $title = home();
    echo '<h1>' .$title. '</h1>';
    require_once 'footer.php';
?>