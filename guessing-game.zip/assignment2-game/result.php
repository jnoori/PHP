<?php
    session_start();

    echo '<p>' . $_SESSION["userName"] . ' lose';
?>