<?php
    function searchWord($arr , $ch){
        foreach ($arr  as $key => $value) {
            if(substr($value, 0, 1)  == $ch){
                return $key;
            }
        }
        return false;
    }
    
?>