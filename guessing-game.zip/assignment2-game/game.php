<?php
  //in this game always start is by user
  require_once('functions.php');
  // start session to use $_SESSION that save our data
  session_start(); 

  //global variables
  // for start button if want to disable button -> disabled
  $_SESSION["start"] = ""; 
  // for submit button if want to disable button -> disabled
  $_SESSION["submit"] = "disabled";
  // for input text if want to disable button -> disabled
  $_SESSION["input"] = "disabled";

  //read name after submit from index page
  if(isset($_GET['submitName'])){ // Check if form was submitted
    $_SESSION["userName"] = $_GET["inputName"]; 
    $_SESSION["computerWordList"] = array(
      'apple',
      'bed',
      'car',
      'cold',
      'door',
      'earth',
      'floor',
      'gold',
      'hand',
      'illegal',
      'jungle',
      'kid',
      'lamp',
      'mother',
      'nurse',
      'old',
      'purple',
      'quit',
      'red',
      'sand',
      'tall',
      'ultra',
      'volt',
      'water',
      'xampp',
      'young',
      'zoo'
    );
    $_SESSION["lastChar"] = "";
    $_SESSION["computerWord"] = "";
    $_SESSION["currentPlayer"] = "user";
    $_SESSION['endGame'] = "";
  }

  //read data after submit
  if(isset($_GET['submit'])){ // Check if form was submitted
    //disable start button
    $_SESSION["start"] = "disabled"; 
    //enable input and submit
    $_SESSION["input"] = "";
    $_SESSION["submit"] = "";
    // put the first last char in a variable
    $firstChar = substr($_GET["inputText"], 0, 1);
    $lastChar = substr($_GET["inputText"], -1); 

    //check the input
    if(empty($_SESSION["lastChar"])){
      $_SESSION["playerWordList"][] = $_GET["inputText"];
      $_SESSION["lastChar"] = $lastChar;
      //searching in arry for not repeated data
    } else if (!in_array($_GET["inputText"] , $_SESSION["playerWordList"]) 
                && $firstChar == $_SESSION["lastChar"]) { 
      $_SESSION["playerWordList"][] = $_GET["inputText"];
      $_SESSION["lastChar"] = $lastChar;
    }else{
      $_SESSION['endGame'] = "end"; // for disabling timer
      header("Location: result.php"); //user lose
    }
     
    //change player to computer
    //computer has just an array to choose the words so
    //when it choose a word it should delete from array
    $_SESSION["currentPlayer"] = "computer";

    // computer turn
    //search a word that start with last word
    $key = searchWord($_SESSION["computerWordList"], $_SESSION["lastChar"]);
    if($key != false){
      $_SESSION["computerWord"] = $_SESSION["computerWordList"][$key];
      $_SESSION['lastChar'] = substr($_SESSION["computerWordList"][$key], -1);
      //put the word empty in array -> instead of deleting
      $_SESSION["computerWordList"][$key] = "";

    }else{
      $_SESSION['endGame'] = "end"; // for disabling timer
      header("Location: result.php"); //computer lose
    }
  }
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
   
    <!-- External CSS -->
    <link rel="stylesheet" href="style.css">
    
    <title>Array Game</title>
  </head>
  <body>
    <div class="container">
        <div class="header">
            <h1>Array Game!</h1>
            
            <!-- here is which one round -->
            <h3 id="playerName" class=<?php echo '"' . $_SESSION["userName"] . '">' . $_SESSION["userName"]; ?>
             </h3>
            <h3 id="count">10</h3>
            <!-- start button -->
            <button id="start" type="button" class="btn btn-primary btn-lg" 
                    <?php echo $_SESSION["start"] ?> >start</button>
        </div> 
        <div class="flex-container">
          <div class="userInput">
            <h3> please enter a word here: </h3>      
            <!-- Start of form -->
            <form action="#" method="GET">
              <input id="inputText" type="text" name="inputText" 
                class="form-control enable" aria-label="Sizing example input" 
                aria-describedby="inputGroup-sizing-sm" <?php echo $_SESSION["input"] ?>/>
              <input id="btnSubmit" class="enable" type="submit" name="submit" value="Submit"
                <?php echo $_SESSION["submit"] ?>/>  
            </form>
          </div> 
          <!-- computer area -->
          <div class="computerInput">
            <h3> computer word:</h3>
            <h3 id="computerInput"> <?php echo $_SESSION["computerWord"] ?></h3>
          </div>
          <div class="result">
            <h3 id="result"><?php echo $_SESSION['endGame'] ?></h3>
          </div>
        </div>  
        
        
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
    <!-- External JS -->
    <script src="main.js"></script>
</body>
</html>