$(document).ready(function(){
  //variables
  var counter = 10; // the time that user have
  var countDown; // count down timer

  //set input empty at the start of the program
  $("#inputText").val('');

  // start timer after refresh the page
  if($("#start").is(":disabled")){ //if btn start has value disabled
    timer();
  }
  if($("#result").text() == 'end'){
    // disable submit and input when time finished
    $(".enable").prop( "disabled", true );
    clearInterval(countDown);
  }
  //timer function
  function timer(){
    countDown = setInterval(function() {
      counter--;
      if (counter >= 0) {
          span = document.getElementById("count");
          span.innerHTML = counter;
      }
      if (counter === 0) {
        let player = $("#playerName").attr('class');
        alert(player+' lose. sorry, out of time!');
        // disable submit and input when time finished
        $(".enable").prop( "disabled", true );
        //stop timer
        clearInterval(countDown);
      }
    }, 1000);
  }
   
  //start timer
  $("#start").click( function(){
      // enalbe input and submit button
      $(".enable").prop( "disabled", false );
      $("#start").prop( "disabled", true );
      timer();
  });

  //stop timer if click submit
  $("#btnSubmit").click(function(){
    clearInterval(countDown);
  });
});


